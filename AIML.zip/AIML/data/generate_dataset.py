"""Download a real monthly Indian rainfall dataset from NASA POWER."""

import calendar
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen

import pandas as pd


LOCATIONS = {
    "Kerala": (8.5241, 76.9366),
    "Karnataka": (12.9716, 77.5946),
    "Maharashtra": (19.0760, 72.8777),
    "Tamil Nadu": (13.0827, 80.2707),
    "Odisha": (20.2961, 85.8245),
    "West Bengal": (22.5726, 88.3639),
    "Assam": (26.1445, 91.7362),
    "Rajasthan": (26.9124, 75.7873),
    "Gujarat": (23.0225, 72.5714),
    "Uttar Pradesh": (26.8467, 80.9462),
    "Bihar": (25.5941, 85.1376),
    "Delhi": (28.6139, 77.2090),
}
API_URL = "https://power.larc.nasa.gov/api/temporal/monthly/point"
PARAMETERS = "PRECTOTCORR,T2M,RH2M,PS,WS2M,CLOUD_AMT"


def fetch_location_data(state: str, latitude: float, longitude: float, start_year: int, end_year: int) -> list[dict]:
    query = urlencode(
        {
            "parameters": PARAMETERS,
            "community": "AG",
            "longitude": longitude,
            "latitude": latitude,
            "start": start_year,
            "end": end_year,
            "format": "JSON",
        }
    )
    with urlopen(f"{API_URL}?{query}", timeout=60) as response:
        payload = json.load(response)

    parameters = payload["properties"]["parameter"]
    records = []
    for date_key, rainfall_per_day in parameters["PRECTOTCORR"].items():
        year = int(date_key[:4])
        month = int(date_key[4:])
        if month > 12:
            continue
        records.append(
            {
                "State": state,
                "Month": month,
                "Temperature_C": round(parameters["T2M"][date_key], 2),
                "Humidity_pct": round(parameters["RH2M"][date_key], 2),
                "Pressure_hPa": round(parameters["PS"][date_key] * 10, 2),
                "WindSpeed_kmph": round(parameters["WS2M"][date_key] * 3.6, 2),
                "CloudCover_pct": round(parameters["CLOUD_AMT"][date_key], 2),
                "Rainfall_mm": round(rainfall_per_day * calendar.monthrange(year, month)[1], 2),
            }
        )
    return records


def build_dataset(start_year: int = 2000, end_year: int = 2023) -> pd.DataFrame:
    records = []
    for state, (latitude, longitude) in LOCATIONS.items():
        records.extend(fetch_location_data(state, latitude, longitude, start_year, end_year))
    return pd.DataFrame(records)


if __name__ == "__main__":
    output_path = Path(__file__).with_name("indian_rainfall_sample.csv")
    dataset = build_dataset()
    dataset.to_csv(output_path, index=False)
    print(f"Downloaded {len(dataset)} real monthly records to {output_path}")
