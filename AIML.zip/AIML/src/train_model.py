"""Train and save the Indian rainfall prediction model."""

from __future__ import annotations

import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder


ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "indian_rainfall_sample.csv"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
FEATURE_COLUMNS = [
    "State",
    "Month",
    "Temperature_C",
    "Humidity_pct",
    "Pressure_hPa",
    "WindSpeed_kmph",
    "CloudCover_pct",
]
TARGET_COLUMN = "Rainfall_mm"


def train() -> dict[str, float]:
    data = pd.read_csv(DATA_PATH)
    missing = set(FEATURE_COLUMNS + [TARGET_COLUMN]) - set(data.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    features = data[FEATURE_COLUMNS].copy()
    target = data[TARGET_COLUMN]
    categorical_features = ["State"]
    numeric_features = [column for column in FEATURE_COLUMNS if column not in categorical_features]

    preprocessor = ColumnTransformer(
        transformers=[
            ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical_features),
            ("numeric", "passthrough", numeric_features),
        ]
    )
    pipeline = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            (
                "model",
                RandomForestRegressor(
                    n_estimators=250,
                    max_depth=16,
                    min_samples_leaf=2,
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    )

    x_train, x_test, y_train, y_test = train_test_split(
        features, target, test_size=0.2, random_state=42
    )
    pipeline.fit(x_train, y_train)
    predictions = pipeline.predict(x_test)
    metrics = {
        "mae_mm": round(float(mean_absolute_error(y_test, predictions)), 2),
        "rmse_mm": round(float(mean_squared_error(y_test, predictions) ** 0.5), 2),
        "r2": round(float(r2_score(y_test, predictions)), 3),
        "training_rows": int(len(x_train)),
        "test_rows": int(len(x_test)),
    }

    MODEL_DIR.mkdir(exist_ok=True)
    REPORT_DIR.mkdir(exist_ok=True)
    joblib.dump(pipeline, MODEL_DIR / "rainfall_model.joblib")
    (MODEL_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    feature_names = pipeline.named_steps["preprocessor"].get_feature_names_out()
    importances = pipeline.named_steps["model"].feature_importances_
    importance_report = pd.DataFrame(
        {"feature": feature_names, "importance": importances}
    ).sort_values("importance", ascending=False)
    importance_report.to_csv(REPORT_DIR / "feature_importance.csv", index=False)

    print(json.dumps(metrics, indent=2))
    print(f"Saved model to {MODEL_DIR / 'rainfall_model.joblib'}")
    return metrics


if __name__ == "__main__":
    train()
