"""Prediction helpers shared by the CLI and Streamlit app."""

from pathlib import Path

import joblib
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "rainfall_model.joblib"


def rainfall_category(rainfall_mm: float) -> str:
    if rainfall_mm < 2.5:
        return "No rain"
    if rainfall_mm < 15:
        return "Light rain"
    if rainfall_mm < 64.5:
        return "Moderate rain"
    if rainfall_mm < 115.5:
        return "Heavy rain"
    return "Very heavy rain"


def predict_rainfall(input_data: dict) -> tuple[float, str]:
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model not found. Run `python src/train_model.py` first.")
    model = joblib.load(MODEL_PATH)
    prediction = float(model.predict(pd.DataFrame([input_data]))[0])
    prediction = max(prediction, 0.0)
    return prediction, rainfall_category(prediction)
